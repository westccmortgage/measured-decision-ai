Measured Decision - Project Record
Project: 3001 Hutton
Record as of: 2026-08-23T07:20:00Z
Every AI reading in this record is Read by AI - not confirmed until a named person signs it. Acceptance as a working baseline is an owner decision, never a technical confirmation. A delivery document is never proof of installation. Absence of evidence is not evidence of absence.
owner-report.pdf - the record, readable
manifest.json - the record, machine-readable, provenance on every value
ai-takeoff.xlsx - the AI takeoff (Read by AI - not confirmed)